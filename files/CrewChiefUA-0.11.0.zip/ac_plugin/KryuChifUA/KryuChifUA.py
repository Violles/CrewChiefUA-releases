# -*- coding: utf-8 -*-
# CrewChief UA — власний застосунок для Assetto Corsa.
# Пише дані всіх машин (позиції, кола, бокси) у спільну пам'ять "KryuChifUA_ac",
# яку читає програма CrewChief UA (спотер, суперники, таблиця, карта).
# Лише стандартні модулі mmap і struct — без ctypes і без сторонніх бібліотек.
# Встановлює і вмикає програма сама; вручну: apps/python/KryuChifUA + увімкнути в налаштуваннях гри.

import ac
import acsys
import mmap
import struct

MAGIC = 0x4B435541          # 'KCUA'
VERSION = 1
MAX_CARS = 64
HEADER = 64
CAR = 176
SIZE = HEADER + MAX_CARS * CAR
NAME = 48

_mem = None
_timer = 0.0
_counter = 0
_logged = False


def _text(s):
    try:
        b = str(s).encode('utf-8')
    except Exception:
        b = b''
    if len(b) > NAME - 1:
        b = b[:NAME - 1].decode('utf-8', 'ignore').encode('utf-8')
    return b + b'\0' * (NAME - len(b))


def _open():
    global _mem
    if _mem is None:
        _mem = mmap.mmap(-1, SIZE, "KryuChifUA_ac")
    return _mem


def _write():
    global _counter
    m = _open()
    n = ac.getCarsCount()
    if n > MAX_CARS:
        n = MAX_CARS
    count = 0
    for i in range(n):
        model = ac.getCarName(i)
        if str(model) == '-1':
            break
        o = HEADER + i * CAR
        pos = ac.getCarState(i, acsys.CS.WorldPosition)
        vel = ac.getCarState(i, acsys.CS.Velocity)
        struct.pack_into('<ii', m, o, i, 1 if (i == 0 or ac.isConnected(i)) else 0)
        m[o + 8:o + 8 + NAME] = _text(ac.getDriverName(i))
        m[o + 56:o + 56 + NAME] = _text(model)
        struct.pack_into('<fiiiii', m, o + 104,
                         float(ac.getCarState(i, acsys.CS.SpeedMS)),
                         int(ac.getCarState(i, acsys.CS.BestLap)),
                         int(ac.getCarState(i, acsys.CS.LapCount)),
                         1 if ac.getCarState(i, acsys.CS.LapInvalidated) else 0,
                         int(ac.getCarState(i, acsys.CS.LapTime)),
                         int(ac.getCarState(i, acsys.CS.LastLap)))
        struct.pack_into('<fff', m, o + 128, float(pos[0]), float(pos[1]), float(pos[2]))
        struct.pack_into('<iii', m, o + 140,
                         1 if ac.isCarInPitline(i) else 0,
                         1 if ac.isCarInPit(i) else 0,
                         int(ac.getCarLeaderboardPosition(i)))
        struct.pack_into('<fi', m, o + 152,
                         float(ac.getCarState(i, acsys.CS.NormalizedSplinePosition)),
                         int(ac.getCarRealTimeLeaderboardPosition(i)))
        struct.pack_into('<fff', m, o + 160, float(vel[0]), float(vel[1]), float(vel[2]))
        count += 1
    _counter = (_counter + 1) & 0x7FFFFFFF
    struct.pack_into('<iiiii', m, 0, MAGIC, VERSION, _counter, count, int(ac.getFocusedCar()))


def acMain(ac_version):
    app = ac.newApp("KryuChifUA")
    ac.setTitle(app, "CrewChief UA")
    ac.setSize(app, 220, 30)
    try:
        _open()
        ac.log("CrewChief UA: shared memory KryuChifUA_ac ready")
    except Exception as e:
        ac.log("CrewChief UA: cannot open shared memory: " + str(e))
    return "KryuChifUA"


def acUpdate(deltaT):
    global _timer, _logged
    _timer += deltaT
    if _timer < 0.025:          # ~40 разів на секунду
        return
    _timer = 0.0
    try:
        _write()
    except Exception as e:
        if not _logged:
            _logged = True
            ac.log("CrewChief UA: " + str(e))


def acShutdown():
    global _mem
    try:
        if _mem is not None:
            struct.pack_into('<i', _mem, 12, 0)
            _mem.close()
    except Exception:
        pass
    _mem = None
