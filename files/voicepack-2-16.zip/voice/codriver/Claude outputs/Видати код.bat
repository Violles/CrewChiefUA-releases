@echo off
chcp 65001 >nul
dotnet "%~dp0KeyGen.dll"
pause
